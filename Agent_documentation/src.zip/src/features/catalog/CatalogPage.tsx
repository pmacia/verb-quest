import { toLocalDate } from '../../shared/time/calendar';
import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../../app/app-context';
import { queryCatalog, formValues } from './query';
import { topicLabel } from './classification-labels';
import { saveList } from './list-service';
import { Icon } from '../../shared/ui/Icon';
import { Dialog } from '../../shared/ui/Dialog';
import { useCatalogAudio } from './use-catalog-audio';
import { CatalogArchiveDialog } from './CatalogArchiveDialog';
import { FamilyFilter } from './FamilyFilter';
import { filterFamilyCandidates, type RelationScope } from './family-filter';
import { IpaHelpButton } from '../phonetics/IpaHelpButton';
import { restoreVerb } from './editor-service';
import { getSpeechService } from '../audio/speech-service';
import { getVerbIcon } from './verb-icons';
import type { Verb, CatalogQuery } from '../../shared/domain/types';
import './catalog-design.css';

const frequency: Record<string, string> = {
  essential: 'Esencial',
  common: 'Frecuente',
  less_common: 'Menos frecuente',
  advanced: 'Avanzado',
};

const topicIcons: Record<string, string> = {
  body_perception: '👁️',
  cognition_mind: '💭',
  communication: '💬',
  daily_life: '🏠',
  finance_money: '💰',
  movement: '🏃',
  nature: '🌿',
  physical_action: '⚡',
  school: '📚',
  state_process: '🔄',
};

const stateMeta: Record<string, { label: string; color: string }> = {
  new: { label: 'Nuevo', color: '#94a3b8' },
  learning: { label: 'En aprendizaje', color: '#00687a' },
  needs_review: { label: 'Necesita refuerzo', color: '#ef4444' },
  consolidating: { label: 'Consolidando', color: '#8b5cf6' },
  mastered: { label: 'Dominado', color: '#10b981' },
};

const relationOptions = [
  { id: 'all_same', label: 'Tres iguales (A-A-A)' },
  { id: 'past_participle_same', label: 'Pasado y participio iguales (A-B-B)' },
  { id: 'all_different', label: 'Tres diferentes (A-B-C)' },
  { id: 'special', label: 'Formas especiales' },
];

function getRelationLabel(rel: string): string {
  if (rel === 'all_same') return 'Tres iguales (A-A-A)';
  if (rel === 'past_participle_same') return 'Pasado y participio iguales (A-B-B)';
  if (rel === 'all_different') return 'Tres diferentes (A-B-C)';
  if (rel === 'special') return 'Formas especiales';
  return rel;
}

const quickSpellings = ['ought', 'ew', 'ent', 'own', 'ung', 'en'];

function getPatternBadge(v: Verb): string {
  const relation = v.classification.formRelation;
  if (relation === 'all_same') return 'Patrón A-A-A';
  if (relation === 'past_participle_same') return 'Patrón A-B-B';
  if (relation === 'all_different') return 'Patrón A-B-C';
  return 'Formas especiales';
}

function getFormIpa(
  v: Verb,
  formKey: 'base' | 'pastSimple' | 'pastParticiple',
  dialect: 'uk' | 'us',
): string {
  const altDialect = dialect === 'uk' ? 'us' : 'uk';
  if (formKey === 'base') {
    return (
      v.forms.base.pronunciation?.[dialect]?.ipa ||
      v.forms.base.pronunciation?.[altDialect]?.ipa ||
      ''
    );
  }
  const variant = v.forms[formKey].variants[0];
  return (
    variant?.pronunciation?.[dialect]?.ipa ||
    variant?.pronunciation?.[altDialect]?.ipa ||
    ''
  );
}

function formatIpa(rawIpa: string): string {
  if (!rawIpa) return '';
  const trimmed = rawIpa.trim();
  if (trimmed.startsWith('/') && trimmed.endsWith('/')) {
    return trimmed;
  }
  return `/${trimmed.replace(/^\/+|\/+$/g, '')}/`;
}

export function CatalogPage() {
  const { verbs, lists, progress, repos, profile, refresh, settings } = useApp();
  const [viewMode, setViewMode] = useState<'expanded' | 'compact'>('expanded');
  const [editing, setEditing] = useState(false);
  const [editNoticeDismissed, setEditNoticeDismissed] = useState(false);

  const [q, setQ] = useState<CatalogQuery>({
    text: '',
    filter: {},
    sort: 'alphabetical',
    direction: 'asc',
  });
  const editToggle = useRef<HTMLButtonElement>(null);
  const focusAfterArchive = useRef(false);
  const [archiving, setArchiving] = useState<Verb | null>(null);

  useEffect(() => {
    if (!archiving && focusAfterArchive.current) {
      focusAfterArchive.current = false;
      editToggle.current?.focus();
    }
  }, [archiving]);

  const [restoring, setRestoring] = useState<string | null>(null);
  const [actionError, setActionError] = useState('');
  const [showArchived, setShowArchived] = useState(false);
  const [familySelection, setFamilySelection] = useState<string[] | null>(null);
  const [filters, setFilters] = useState(false);
  const [selected, setSelected] = useState<string[]>([]);
  const [newList, setNewList] = useState(false);
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  const familyCatalog = showArchived
    ? verbs.filter((v) => v.archivedAt).map((v) => ({ ...v, archivedAt: null }))
    : verbs.filter((v) => !v.archivedAt);

  const relation = (q.filter.relations?.[0] ?? '') as RelationScope;

  const result = queryCatalog(
    filterFamilyCandidates(familyCatalog, relation, familySelection),
    q,
    {
      lists,
      progress,
      strictIpa: settings.strictIpa === true,
      today: toLocalDate(new Date().toISOString(), settings.timeZone),
    },
  );

  const audio = useCatalogAudio(result.items.map((v) => v.id));

  async function playSingleForm(text: string, dialect: 'uk' | 'us') {
    const speech = getSpeechService();
    await speech.play({
      text,
      voiceURI: settings.voiceURI,
      preferredDialect: dialect,
      volume: settings.volume,
      rate: settings.rate,
    });
  }

  function filter(key: string, value: string) {
    setQ({ ...q, filter: { ...q.filter, [key]: value ? [value] : [] } });
  }

  const active = Object.entries(q.filter).filter(([, v]) => Array.isArray(v) && v.length);

  function clearFilters() {
    setQ({ ...q, filter: {} });
    setFamilySelection(null);
  }

  const filterCount = active.length + (familySelection !== null ? 1 : 0);

  return (
    <div className="catalog-page-container">
      {/* Top Header Panel with Stitch Typography & iOS Edit Switch */}
      <header className="catalog-header-panel">

        <div>
          <span className="eyebrow">EXPLORA · DESCUBRE · APRENDE</span>
          <div className="catalog-title-badge-wrap">
            <h1>
              Verbos Irregulares<span className="dot">.</span>
            </h1>
            <span className="catalog-badge-total">{result.total}</span>
          </div>
          <p>Domina los verbos clave en inglés</p>
        </div>


        <div className="catalog-top-controls">
          {/* View Mode Selector Tabs (Detallada / Compacta) */}
          <div className="view-tabs-container" role="tablist" aria-label="Modo de visualización">
            <button
              type="button"
              role="tab"
              aria-selected={viewMode === 'expanded'}
              className={`view-tab-btn ${viewMode === 'expanded' ? 'active' : ''}`}
              onClick={() => setViewMode('expanded')}
              title="Vista Detallada (Tarjetas con 3 pilares)"
            >
              <span className="material-symbols-outlined" style={{ fontSize: '16px' }}>
                view_agenda
              </span>
              <span>Detallada</span>
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={viewMode === 'compact'}
              className={`view-tab-btn ${viewMode === 'compact' ? 'active' : ''}`}
              onClick={() => setViewMode('compact')}
              title="Vista Compacta (Fila rápida)"
            >
              <span className="material-symbols-outlined" style={{ fontSize: '16px' }}>
                table_rows
              </span>
              <span>Compacta</span>
            </button>
          </div>

          {/* iOS-Style Edit Mode Switch */}
          <div className="ios-toggle-wrap">
            <label htmlFor="catalog-edit-toggle">Modo Edición</label>
            <button
              ref={editToggle}
              id="catalog-edit-toggle"
              type="button"
              role="switch"
              aria-checked={editing}
              aria-label="Modo de edición del catálogo"
              className={`ios-switch-btn ${editing ? 'checked' : ''}`}
              onClick={() => {
                const next = !editing;
                setEditing(next);
                if (next) {
                  setEditNoticeDismissed(false);
                }
              }}
            >
              <span className="ios-switch-thumb" />
            </button>
          </div>

          {/* + Nuevo Verbo Button Beside Switch (shown when editing is active) */}
          {editing && (
            <Link
              to="/editor/verbs/new"
              className="new-verb-header-btn"
              title="Crear nuevo verbo"
              aria-label="Crear nuevo verbo"
            >
              <span className="material-symbols-outlined" style={{ fontSize: '17px' }}>
                add
              </span>
              <span>Nuevo verbo</span>
            </Link>
          )}
        </div>
      </header>

      {/* Edit Mode Notice Banner (dismissible) */}
      {editing && !editNoticeDismissed && (
        <div className="catalog-edit-banner" role="status">
          <div className="catalog-edit-banner-left">
            <span className="material-symbols-outlined" style={{ fontSize: '20px' }}>
              edit_note
            </span>
            <div>
              <strong>Modo Edición Activado</strong> — Puedes modificar conjugaciones o archivar
              verbos de tu catálogo con los botones de cada tarjeta.
            </div>
          </div>
          <button
            type="button"
            className="catalog-edit-banner-close"
            onClick={() => setEditNoticeDismissed(true)}
            aria-label="Cerrar aviso de modo edición"
            title="Cerrar aviso"
          >
            <span className="material-symbols-outlined" style={{ fontSize: '18px' }}>
              close
            </span>
          </button>
        </div>
      )}

      {audio.message && (
        <p className="catalog-audio-status" role="status">
          {audio.message}
        </p>
      )}

      {actionError && <p role="alert">{actionError}</p>}

      {archiving && (
        <CatalogArchiveDialog
          verb={archiving}
          onClose={() => setArchiving(null)}
          onArchived={() => {
            setSelected(selected.filter((id) => id !== archiving.id));
            focusAfterArchive.current = true;
            setArchiving(null);
          }}
        />
      )}

      {/* Layout Grid: Main Catalog Column + Aside Column */}
      <div className="catalog-layout">
        <section>
          {/* Search Bar & Action Toolbar */}
          <div className="catalog-search-card">
            {/* Search Input Box */}
            <div className="catalog-search-input-box">
              <span
                className="material-symbols-outlined"
                style={{ fontSize: '20px', color: 'var(--muted, #64748b)' }}
              >
                search
              </span>
              <input
                id="verb-search-input"
                aria-label="Buscar verbos"
                placeholder="Buscar infinitivo, pasado, español..."
                value={q.text}
                onChange={(e) => setQ({ ...q, text: e.target.value })}
              />
              {q.text && (
                <button
                  type="button"
                  className="catalog-search-clear-btn"
                  onClick={() => setQ({ ...q, text: '' })}
                  aria-label="Limpiar búsqueda"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Quick Action Tools (Filtros button, Sort, Selection count) */}
            <div className="catalog-tools-row">
              <div className="catalog-tools-left">
                <button
                  type="button"
                  className={`catalog-filters-trigger ${filters ? 'active' : ''}`}
                  onClick={() => setFilters(!filters)}
                  aria-expanded={filters}
                >
                  <span className="material-symbols-outlined" style={{ fontSize: '18px' }}>
                    tune
                  </span>
                  <span>Filtros</span>
                  {filterCount > 0 && (
                    <span className="catalog-filter-count-badge">{filterCount}</span>
                  )}
                </button>

                <select
                  aria-label="Ordenar verbos"
                  className="catalog-sort-select"
                  value={q.sort}
                  onChange={(e) => setQ({ ...q, sort: e.target.value as CatalogQuery['sort'] })}
                >
                  {[
                    ['alphabetical', 'A → Z'],
                    ['frequency', 'Frecuencia'],
                    ['course', 'Curso'],
                    ['mastery', 'Aprendizaje'],
                    ['difficulty', 'Dificultad'],
                    ['review', 'Prioridad de repaso'],
                  ].map(([v, l]) => (
                    <option key={v} value={v}>
                      {l}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Horizontal Filter Pills Stream (Stitch Specification) */}
            <div className="catalog-pills-stream" aria-label="Filtros rápidos">
              <button
                type="button"
                className={`stitch-pill-all-btn ${filterCount === 0 ? 'is-active' : ''}`}
                onClick={clearFilters}
              >
                Todos
              </button>

              {q.filter.courses?.[0] && (() => {
                const val = q.filter.courses[0];
                const n = val.replace('eso', '');
                return (
                  <span className="stitch-active-pill pill-teal">
                    <span className="stitch-pill-dot" style={{ backgroundColor: '#00687a' }} />
                    <span className="stitch-pill-label">{n}º ESO</span>
                    <button
                      type="button"
                      className="stitch-pill-remove-btn"
                      onClick={() => filter('courses', '')}
                      aria-label="Eliminar filtro de curso"
                      title="Eliminar filtro de curso"
                    >
                      <span className="material-symbols-outlined" style={{ fontSize: '14px' }}>
                        close
                      </span>
                    </button>
                  </span>
                );
              })()}

              {relation && (() => {
                const patternLabel =
                  relation === 'all_same'
                    ? 'Patrón A-A-A'
                    : relation === 'past_participle_same'
                    ? 'Patrón A-B-B'
                    : relation === 'all_different'
                    ? 'Patrón A-B-C'
                    : 'Patrón Especial';
                return (
                  <span className="stitch-active-pill pill-purple">
                    <span className="stitch-pill-dot" style={{ backgroundColor: '#571ac0' }} />
                    <span className="stitch-pill-label">{patternLabel}</span>
                    <button
                      type="button"
                      className="stitch-pill-remove-btn"
                      onClick={() => {
                        filter('relations', '');
                        setFamilySelection(null);
                      }}
                      aria-label="Eliminar filtro de patrón"
                      title="Eliminar filtro de patrón"
                    >
                      <span className="material-symbols-outlined" style={{ fontSize: '14px' }}>
                        close
                      </span>
                    </button>
                  </span>
                );
              })()}

              {familySelection !== null && (
                <span className="stitch-active-pill pill-indigo">
                  <span
                    className="material-symbols-outlined"
                    style={{ fontSize: '14px', color: '#4f46e5' }}
                  >
                    account_tree
                  </span>
                  <span className="stitch-pill-label">Familias ({familySelection.length})</span>
                  <button
                    type="button"
                    className="stitch-pill-remove-btn"
                    onClick={() => setFamilySelection(null)}
                    aria-label="Restablecer filtro de familias"
                    title="Restablecer filtro de familias"
                  >
                    <span className="material-symbols-outlined" style={{ fontSize: '14px' }}>
                      close
                    </span>
                  </button>
                </span>
              )}

              {q.filter.frequencies?.[0] && (() => {
                const val = q.filter.frequencies[0];
                const isEssential = val === 'essential';
                const isFrequent = val === 'frequent';
                const icon = isEssential ? '🔥' : isFrequent ? '⭐' : '📌';
                const label = frequency[val] || val;
                return (
                  <span className="stitch-active-pill pill-surface">
                    <span className="stitch-pill-icon">{icon}</span>
                    <span className="stitch-pill-label">{label}</span>
                    <button
                      type="button"
                      className="stitch-pill-remove-btn"
                      onClick={() => filter('frequencies', '')}
                      aria-label="Eliminar filtro de frecuencia"
                      title="Eliminar filtro de frecuencia"
                    >
                      <span className="material-symbols-outlined" style={{ fontSize: '14px' }}>
                        close
                      </span>
                    </button>
                  </span>
                );
              })()}

              {q.filter.states?.[0] && (() => {
                const val = q.filter.states[0];
                const meta = stateMeta[val];
                const colorClass =
                  val === 'needs_review'
                    ? 'pill-coral'
                    : val === 'consolidating'
                    ? 'pill-purple'
                    : val === 'mastered'
                    ? 'pill-emerald'
                    : 'pill-teal';
                const dotColor =
                  val === 'needs_review'
                    ? '#ba1a1a'
                    : val === 'consolidating'
                    ? '#571ac0'
                    : val === 'mastered'
                    ? '#10b981'
                    : '#00687a';
                return (
                  <span className={`stitch-active-pill ${colorClass}`}>
                    <span
                      className="stitch-pill-dot"
                      style={{ backgroundColor: dotColor }}
                    />
                    <span className="stitch-pill-label">{meta?.label || val}</span>
                    <button
                      type="button"
                      className="stitch-pill-remove-btn"
                      onClick={() => filter('states', '')}
                      aria-label="Eliminar filtro de estado"
                      title="Eliminar filtro de estado"
                    >
                      <span className="material-symbols-outlined" style={{ fontSize: '14px' }}>
                        close
                      </span>
                    </button>
                  </span>
                );
              })()}

              {q.filter.topics?.[0] && (() => {
                const top = q.filter.topics[0];
                const icon = topicIcons[top] || '📌';
                return (
                  <span className="stitch-active-pill pill-indigo">
                    <span className="stitch-pill-icon">{icon}</span>
                    <span className="stitch-pill-label">{topicLabel(top)}</span>
                    <button
                      type="button"
                      className="stitch-pill-remove-btn"
                      onClick={() => filter('topics', '')}
                      aria-label="Eliminar filtro de tema"
                      title="Eliminar filtro de tema"
                    >
                      <span className="material-symbols-outlined" style={{ fontSize: '14px' }}>
                        close
                      </span>
                    </button>
                  </span>
                );
              })()}

              {q.filter.spelling?.[0]?.ending && (() => {
                const ending = q.filter.spelling[0].ending;
                return (
                  <span className="stitch-active-pill pill-purple font-mono">
                    <span className="stitch-pill-dot" style={{ backgroundColor: '#571ac0' }} />
                    <span className="stitch-pill-label">Term.: -{ending}</span>
                    <button
                      type="button"
                      className="stitch-pill-remove-btn"
                      onClick={() => setQ({ ...q, filter: { ...q.filter, spelling: [] } })}
                      aria-label="Eliminar filtro de terminación"
                      title="Eliminar filtro de terminación"
                    >
                      <span className="material-symbols-outlined" style={{ fontSize: '14px' }}>
                        close
                      </span>
                    </button>
                  </span>
                );
              })()}

              {/* Quick "+ Añadir filtro" / toggle chip directly in stream (Stitch Specification) */}
              <button
                type="button"
                className="stitch-add-filter-chip-btn"
                onClick={() => setFilters(!filters)}
                aria-expanded={filters}
                title={filters ? 'Ocultar filtros avanzados' : 'Añadir filtros avanzados'}
              >
                <span className="material-symbols-outlined" style={{ fontSize: '15px' }}>
                  {filters ? 'expand_less' : 'add'}
                </span>
                <span>{filters ? 'Ocultar panel' : 'Añadir filtro'}</span>
              </button>
            </div>

            {/* Collapsible Advanced Filters Panel (Stitch Prototype Specification) */}
            {filters && (
              <div
                className="stitch-filter-panel"
                id="filter-panel"
                role="region"
                aria-label="Panel de filtros avanzados"
              >
                {/* Header with Title, Subtitle, Reset and Close buttons */}
                <div className="filter-panel-header">
                  <div className="filter-panel-title-group">
                    <div className="filter-panel-icon-box" aria-hidden="true">
                      <span className="material-symbols-outlined" style={{ fontSize: '20px' }}>
                        tune
                      </span>
                    </div>
                    <div>
                      <span className="filter-panel-title">Filtros Avanzados</span>
                      <span className="filter-panel-subtitle">Personaliza tu lista de verbos irregulares</span>
                    </div>
                  </div>
                  <div className="filter-panel-header-actions">
                    {filterCount > 0 && (
                      <button
                        type="button"
                        className="filter-panel-reset-btn"
                        onClick={clearFilters}
                        title="Restablecer todos los filtros"
                      >
                        <span className="material-symbols-outlined" style={{ fontSize: '15px' }}>
                          restart_alt
                        </span>
                        <span>Limpiar ({filterCount})</span>
                      </button>
                    )}
                    <button
                      type="button"
                      className="filter-panel-close-btn"
                      onClick={() => setFilters(false)}
                      aria-label="Cerrar panel de filtros"
                      title="Cerrar filtros"
                    >
                      <span className="material-symbols-outlined" style={{ fontSize: '20px' }}>
                        close
                      </span>
                    </button>
                  </div>
                </div>

                {/* Filter Sections Container */}
                <div className="filter-panel-sections">
                  {/* Top 3-Column Grid for Curso, Frecuencia, Estado (Stitch Layout) */}
                  <div className="filter-panel-top-grid">
                    {/* 1. Curso Escolar */}
                    <div className="filter-grid-col">
                      <div className="filter-section-header">
                        <span className="material-symbols-outlined" style={{ fontSize: '15px', color: '#4f46e5' }}>
                          school
                        </span>
                        <span>Curso Escolar</span>
                      </div>
                      <div className="filter-chips-wrap">
                        <button
                          type="button"
                          className={`stitch-chip-btn ${!q.filter.courses?.[0] ? 'active' : ''}`}
                          onClick={() => filter('courses', '')}
                        >
                          Todos
                        </button>
                        {[1, 2, 3, 4].map((n) => {
                          const val = `eso${n}`;
                          const isSelected = q.filter.courses?.[0] === val;
                          return (
                            <button
                              type="button"
                              key={val}
                              className={`stitch-chip-btn ${isSelected ? 'stitch-chip-teal-active' : ''}`}
                              onClick={() => filter('courses', isSelected ? '' : val)}
                            >
                              {n}º ESO
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* 2. Frecuencia de Uso */}
                    <div className="filter-grid-col">
                      <div className="filter-section-header">
                        <span className="material-symbols-outlined" style={{ fontSize: '15px', color: '#00687a' }}>
                          trending_up
                        </span>
                        <span>Frecuencia de Uso</span>
                      </div>
                      <div className="filter-chips-wrap">
                        <button
                          type="button"
                          className={`stitch-chip-btn ${!q.filter.frequencies?.[0] ? 'active' : ''}`}
                          onClick={() => filter('frequencies', '')}
                        >
                          Todas
                        </button>
                        {Object.entries(frequency).map(([val, label]) => {
                          const isSelected = q.filter.frequencies?.[0] === val;
                          const chipClass =
                            val === 'essential'
                              ? 'stitch-chip-teal-active'
                              : val === 'frequent'
                              ? 'stitch-chip-indigo-active'
                              : val === 'advanced'
                              ? 'stitch-chip-purple-active'
                              : 'active';
                          return (
                            <button
                              type="button"
                              key={val}
                              className={`stitch-chip-btn ${isSelected ? chipClass : ''}`}
                              onClick={() => filter('frequencies', isSelected ? '' : val)}
                            >
                              {val === 'essential' ? `🔥 ${label}` : label}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* 3. Estado de Aprendizaje */}
                    <div className="filter-grid-col">
                      <div className="filter-section-header">
                        <span className="material-symbols-outlined" style={{ fontSize: '15px', color: '#4f46e5' }}>
                          psychology
                        </span>
                        <span>Estado de Aprendizaje</span>
                      </div>
                      <div className="filter-chips-wrap">
                        <button
                          type="button"
                          className={`stitch-chip-btn ${!q.filter.states?.[0] ? 'active' : ''}`}
                          onClick={() => filter('states', '')}
                        >
                          Todos
                        </button>
                        {Object.entries(stateMeta).map(([val, meta]) => {
                          const isSelected = q.filter.states?.[0] === val;
                          const chipClass =
                            val === 'learning'
                              ? 'stitch-chip-teal-active'
                              : val === 'needs_review'
                              ? 'stitch-chip-coral-active'
                              : val === 'consolidating'
                              ? 'stitch-chip-purple-active'
                              : val === 'mastered'
                              ? 'stitch-chip-emerald-active'
                              : 'active';
                          return (
                            <button
                              type="button"
                              key={val}
                              className={`stitch-chip-btn ${isSelected ? chipClass : ''}`}
                              onClick={() => filter('states', isSelected ? '' : val)}
                            >
                              <span
                                className="status-dot-indicator"
                                style={{ backgroundColor: meta.color }}
                                aria-hidden="true"
                              />
                              <span>{meta.label}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* 4. Tema Semántico */}
                  <div className="filter-section filter-section-divider">
                    <div className="filter-section-header">
                      <span className="material-symbols-outlined" style={{ fontSize: '15px', color: '#571ac0' }}>
                        category
                      </span>
                      <span>Tema Semántico</span>
                    </div>
                    <div className="filter-chips-scroll">
                      <button
                        type="button"
                        className={`stitch-chip-btn ${!q.filter.topics?.[0] ? 'active' : ''}`}
                        onClick={() => filter('topics', '')}
                      >
                        Todos
                      </button>
                      {[...new Set(verbs.flatMap((v) => v.classification.topics ?? []))]
                        .sort()
                        .map((top) => {
                          const isSelected = q.filter.topics?.[0] === top;
                          const icon = topicIcons[top] || '📌';
                          return (
                            <button
                              type="button"
                              key={top}
                              className={`stitch-chip-btn ${isSelected ? 'stitch-chip-indigo-active' : ''}`}
                              onClick={() => filter('topics', isSelected ? '' : top)}
                            >
                              <span>{icon}</span>
                              <span>{topicLabel(top)}</span>
                            </button>
                          );
                        })}
                    </div>
                  </div>

                  {/* 5. Relación de Formas y Familias (Full Granular Stitch Filter) */}
                  <div className="filter-section filter-section-divider">
                    <FamilyFilter
                      verbs={familyCatalog}
                      relation={relation}
                      selected={familySelection}
                      onRelation={(value) => {
                        filter('relations', value);
                        setFamilySelection(null);
                      }}
                      onSelection={setFamilySelection}
                    />
                  </div>

                  {/* 6. Terminación Escrita (Pasado Simple) */}
                  <div className="filter-section filter-section-divider">
                    <div className="filter-section-header">
                      <span className="material-symbols-outlined" style={{ fontSize: '15px', color: '#571ac0' }}>
                        spellcheck
                      </span>
                      <span>Terminación Escrita (Pasado Simple)</span>
                    </div>
                    <div className="spelling-input-row">
                      {quickSpellings.map((ending) => {
                        const isSelected = q.filter.spelling?.[0]?.ending === ending;
                        return (
                          <button
                            type="button"
                            key={ending}
                            className={`stitch-chip-btn font-mono ${isSelected ? 'stitch-chip-purple-active' : ''}`}
                            onClick={() =>
                              setQ({
                                ...q,
                                filter: {
                                  ...q.filter,
                                  spelling: isSelected
                                    ? []
                                    : [{ form: 'pastSimple', ending }],
                                },
                              })
                            }
                          >
                            -{ending}
                          </button>
                        );
                      })}
                      <input
                        className="spelling-custom-input"
                        placeholder="Otra (ej. ought)"
                        aria-label="Terminación escrita personalizada"
                        value={q.filter.spelling?.[0]?.ending ?? ''}
                        onChange={(e) =>
                          setQ({
                            ...q,
                            filter: {
                              ...q.filter,
                              spelling: e.target.value
                                ? [{ form: 'pastSimple', ending: e.target.value.trim() }]
                                : [],
                            },
                          })
                        }
                      />
                    </div>
                  </div>

                  {/* 7. Modo Edición: Verbos Archivados */}
                  {editing && (
                    <div className="filter-section">
                      <label style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontSize: '12.5px', fontWeight: 600 }}>
                        <input
                          type="checkbox"
                          className="card-checkbox"
                          checked={showArchived}
                          onChange={(e) => setShowArchived(e.target.checked)}
                        />
                        <span>Mostrar verbos archivados del catálogo</span>
                      </label>
                    </div>
                  )}
                </div>

                {/* Footer with IpaHelpButton, Clear and Done/Apply buttons */}
                <div className="filter-panel-footer">
                  <IpaHelpButton />
                  <div className="filter-panel-footer-actions">
                    <button
                      type="button"
                      className="filter-panel-clear-action"
                      onClick={clearFilters}
                    >
                      <span className="material-symbols-outlined" style={{ fontSize: '16px' }}>
                        restart_alt
                      </span>
                      <span>Limpiar filtros</span>
                    </button>
                    <button
                      type="button"
                      className="filter-panel-apply-action"
                      onClick={() => setFilters(false)}
                    >
                      <span>Aplicar ({result.total} {result.total === 1 ? 'verbo' : 'verbos'})</span>
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Integrated Selection Feedback Banner */}
          {selected.length > 0 && (
            <div className="catalog-selection-banner" role="region" aria-live="polite">
              <button
                type="button"
                className="selection-banner-close-corner"
                title="Deseleccionar todos"
                onClick={() => setSelected([])}
                aria-label="Deseleccionar todos"
              >
                <span className="material-symbols-outlined" style={{ fontSize: '18px' }}>
                  close
                </span>
              </button>

              <div className="selection-banner-left">
                <div className="selection-banner-icon-box" aria-hidden="true">
                  <span className="material-symbols-outlined" style={{ fontSize: '20px' }}>
                    checklist
                  </span>
                </div>
                <div className="selection-banner-info">
                  <div className="selection-banner-title-row">
                    <span className="selection-banner-title">
                      <strong>{selected.length}</strong>{' '}
                      {selected.length === 1 ? 'verbo seleccionado' : 'verbos seleccionados'}
                    </span>
                    <span className="selection-banner-pill">
                      Selección activa
                    </span>
                  </div>
                  <p className="selection-banner-desc">
                    Puedes guardar estos verbos en una lista de estudio o repasar sus conjugaciones.
                  </p>
                </div>
              </div>

              <div className="selection-banner-actions">
                <button
                  type="button"
                  className="selection-save-btn"
                  onClick={() => setNewList(true)}
                >
                  <span className="material-symbols-outlined" style={{ fontSize: '17px' }}>
                    bookmark_add
                  </span>
                  <span>Guardar en lista</span>
                </button>
              </div>
            </div>
          )}

          {/* Detailed Cards View (Stitch Design Specification) */}
          {viewMode === 'expanded' ? (
            <div className="verb-cards-list" id="verb-list-container">
              {result.items.map((v) => {
                const isSelected = selected.includes(v.id);
                const baseIpa = getFormIpa(v, 'base', settings.dialect);
                const pastIpa = getFormIpa(v, 'pastSimple', settings.dialect);
                const partIpa = getFormIpa(v, 'pastParticiple', settings.dialect);
                const pastValues = formValues(v, 'pastSimple');
                const partValues = formValues(v, 'pastParticiple');
                const emoji = getVerbIcon(v.lemma, v.classification.topics?.[0]);
                const pattern = getPatternBadge(v);
                const course = v.classification.recommendedCourses?.[0]
                  ? `${v.classification.recommendedCourses[0].replace('eso', '')}º ESO`
                  : null;
                const freqLabel = frequency[v.classification.frequencyBand] || 'Frecuente';
                const mnemonic = v.mnemonics?.[0] || v.examples?.[0]?.sentence || v.meaningNotes;

                return (
                  <article
                    className={`stitch-verb-card ${isSelected ? 'is-selected' : ''}`}
                    key={v.id}
                  >
                    {/* Verb Card Top Header */}
                    <div className="verb-card-top">
                      <div className="verb-card-top-left">
                        <div className="verb-title-block">
                          <div className="verb-title-flex">
                            <label
                              className="card-corner-checkbox-wrap"
                              title={`Seleccionar ${v.lemma}`}
                            >
                              <input
                                type="checkbox"
                                className="card-checkbox"
                                aria-label={`Seleccionar ${v.lemma}`}
                                checked={isSelected}
                                onChange={(e) =>
                                  setSelected(
                                    e.target.checked
                                      ? [...selected, v.id]
                                      : selected.filter((id) => id !== v.id),
                                  )
                                }
                              />
                            </label>
                            <span className="card-avatar-box" aria-hidden="true">
                              {emoji}
                            </span>
                            <Link to={`/verbs/${v.id}`} className="verb-lemma-link">
                              {v.lemma}
                            </Link>
                            <span className="verb-meaning-text">
                              {v.meanings.slice(0, 2).join(' / ')}
                            </span>
                          </div>
                          <div className="verb-tags-flex">
                            {course && <span className="card-tag tag-level">{course}</span>}
                            <span className="card-tag tag-pattern">{pattern}</span>
                            <span className="card-tag tag-freq">🔥 {freqLabel}</span>
                          </div>
                        </div>
                      </div>

                      {/* Card Action Controls & Chevron CTA */}
                      <div className="verb-card-top-right">
                        {editing && (
                          <>
                            <Link
                              to={`/editor/verbs/${v.id}`}
                              className="card-tool-btn"
                              aria-label={`Editar ${v.lemma}`}
                              title="Editar verbo"
                            >
                              <span
                                className="material-symbols-outlined"
                                style={{ fontSize: '16px' }}
                              >
                                edit
                              </span>
                            </Link>
                            {showArchived ? (
                              <button
                                type="button"
                                className="card-tool-btn"
                                aria-label={`Restaurar ${v.lemma}`}
                                title="Restaurar verbo"
                                disabled={restoring === v.id}
                                onClick={async () => {
                                  setRestoring(v.id);
                                  setActionError('');
                                  try {
                                    await restoreVerb(repos, v.id);
                                    await refresh();
                                    editToggle.current?.focus();
                                  } catch {
                                    setActionError(
                                      'No se pudo restaurar el verbo. Inténtalo de nuevo.',
                                    );
                                  } finally {
                                    setRestoring(null);
                                  }
                                }}
                              >
                                <span
                                  className="material-symbols-outlined"
                                  style={{ fontSize: '16px' }}
                                >
                                  restore
                                </span>
                              </button>
                            ) : (
                              <button
                                type="button"
                                className="card-tool-btn danger"
                                aria-label={`Quitar ${v.lemma} del catálogo`}
                                title="Archivar verbo"
                                onClick={() => setArchiving(v)}
                              >
                                <span
                                  className="material-symbols-outlined"
                                  style={{ fontSize: '16px' }}
                                >
                                  delete
                                </span>
                              </button>
                            )}
                          </>
                        )}
                        <button
                          type="button"
                          className="card-tool-btn"
                          aria-pressed={audio.playingId === v.id}
                          aria-label={
                            audio.playingId === v.id
                              ? `Detener audio de ${v.lemma}`
                              : `Escuchar las tres formas de ${v.lemma}`
                          }
                          title="Escuchar las tres formas seguidas"
                          onClick={() => void audio.play(v)}
                        >
                          <span
                            className="material-symbols-outlined"
                            style={{ fontSize: '17px' }}
                          >
                            volume_up
                          </span>
                        </button>
                        <Link
                          to={`/verbs/${v.id}`}
                          className="card-nav-arrow-btn"
                          aria-label={`Ver ficha de ${v.lemma}`}
                          title="Ver ficha completa"
                        >
                          <span
                            className="material-symbols-outlined"
                            style={{ fontSize: '19px' }}
                          >
                            chevron_right
                          </span>
                        </Link>
                      </div>
                    </div>

                    {/* Conjugation Grid (3 Pillars: Infinitive, Past Simple, Past Participle) */}
                    <div className="pillars-grid-3">
                      {/* 1. Infinitive Pillar */}
                      <div className="pillar-column">
                        <div className="pillar-title-row">
                          <span className="pillar-heading-label">Infinitive</span>
                          <span className="pillar-colored-dot base" />
                        </div>
                        <div className="pillar-word-text">{v.lemma}</div>
                        <div className="pillar-ipa-audio-bar">
                          <span className="pillar-ipa-code">{baseIpa || '—'}</span>
                          <div className="pillar-sound-buttons">
                            <button
                              type="button"
                              className="pillar-sound-btn"
                              title="Audio UK"
                              onClick={() => void playSingleForm(v.lemma, 'uk')}
                            >
                              <span>UK</span>
                              <span
                                className="material-symbols-outlined"
                                style={{ fontSize: '14px' }}
                              >
                                volume_up
                              </span>
                            </button>
                            <button
                              type="button"
                              className="pillar-sound-btn"
                              title="Audio US"
                              onClick={() => void playSingleForm(v.lemma, 'us')}
                            >
                              <span>US</span>
                              <span
                                className="material-symbols-outlined"
                                style={{ fontSize: '14px' }}
                              >
                                volume_up
                              </span>
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* 2. Past Simple Pillar */}
                      <div className="pillar-column">
                        <div className="pillar-title-row">
                          <span className="pillar-heading-label">Past Simple</span>
                          <span className="pillar-colored-dot past" />
                        </div>
                        <div className="pillar-word-text past">
                          {pastValues.join(' / ') || '—'}
                        </div>
                        <div className="pillar-ipa-audio-bar">
                          <span className="pillar-ipa-code">{pastIpa || '—'}</span>
                          <div className="pillar-sound-buttons">
                            <button
                              type="button"
                              className="pillar-sound-btn"
                              title="Audio UK"
                              onClick={() => void playSingleForm(pastValues[0] || v.lemma, 'uk')}
                            >
                              <span>UK</span>
                              <span
                                className="material-symbols-outlined"
                                style={{ fontSize: '14px' }}
                              >
                                volume_up
                              </span>
                            </button>
                            <button
                              type="button"
                              className="pillar-sound-btn"
                              title="Audio US"
                              onClick={() => void playSingleForm(pastValues[0] || v.lemma, 'us')}
                            >
                              <span>US</span>
                              <span
                                className="material-symbols-outlined"
                                style={{ fontSize: '14px' }}
                              >
                                volume_up
                              </span>
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* 3. Past Participle Pillar */}
                      <div className="pillar-column">
                        <div className="pillar-title-row">
                          <span className="pillar-heading-label">Past Participle</span>
                          <span className="pillar-colored-dot participle" />
                        </div>
                        <div className="pillar-word-text participle">
                          {partValues.join(' / ') || '—'}
                        </div>
                        <div className="pillar-ipa-audio-bar">
                          <span className="pillar-ipa-code">{partIpa || '—'}</span>
                          <div className="pillar-sound-buttons">
                            <button
                              type="button"
                              className="pillar-sound-btn"
                              title="Audio UK"
                              onClick={() => void playSingleForm(partValues[0] || v.lemma, 'uk')}
                            >
                              <span>UK</span>
                              <span
                                className="material-symbols-outlined"
                                style={{ fontSize: '14px' }}
                              >
                                volume_up
                              </span>
                            </button>
                            <button
                              type="button"
                              className="pillar-sound-btn"
                              title="Audio US"
                              onClick={() => void playSingleForm(partValues[0] || v.lemma, 'us')}
                            >
                              <span>US</span>
                              <span
                                className="material-symbols-outlined"
                                style={{ fontSize: '14px' }}
                              >
                                volume_up
                              </span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Card Mini Footer Tip & Examples CTA */}
                    <div className="card-mini-footer">
                      <span className="card-footer-tip" title={mnemonic}>
                        <span
                          className="material-symbols-outlined"
                          style={{ fontSize: '16px', color: '#8b5cf6' }}
                        >
                          lightbulb
                        </span>
                        <span>
                          {mnemonic ? `Tip: ${mnemonic}` : 'Recuerda practicar sus tres formas.'}
                        </span>
                      </span>
                      <Link to={`/verbs/${v.id}`} className="card-footer-action-link">
                        <span>Ver ejemplos</span>
                        <span
                          className="material-symbols-outlined"
                          style={{ fontSize: '14px' }}
                        >
                          arrow_forward
                        </span>
                      </Link>
                    </div>
                  </article>
                );
              })}
            </div>
          ) : (
            /* Streamlined Compact Mode (Stitch Prototype Specification) */
            <div className="verb-compact-list" id="verb-compact-container">
              {result.items.map((v) => {
                const isSelected = selected.includes(v.id);
                const baseIpa = getFormIpa(v, 'base', settings.dialect);
                const pastIpa = getFormIpa(v, 'pastSimple', settings.dialect);
                const partIpa = getFormIpa(v, 'pastParticiple', settings.dialect);
                const pastValues = formValues(v, 'pastSimple');
                const partValues = formValues(v, 'pastParticiple');
                const emoji = getVerbIcon(v.lemma, v.classification.topics?.[0]);
                const pattern = getPatternBadge(v);
                const cefrLevel =
                  v.classification.recommendedCourses?.[0] === 'eso1'
                    ? 'A1'
                    : v.classification.recommendedCourses?.[0] === 'eso2'
                    ? 'A2'
                    : v.classification.recommendedCourses?.[0] === 'eso3'
                    ? 'B1'
                    : v.classification.recommendedCourses?.[0] === 'eso4'
                    ? 'B2'
                    : 'A2';

                return (
                  <div
                    key={v.id}
                    className={`stitch-compact-row ${isSelected ? 'is-selected' : ''}`}
                  >
                    {/* Left: Squircle Avatar (sin caja) + Lemma & Meaning + Phonetics */}
                    <div className="compact-left-group">
                      <div className="compact-text-block">
                        <div className="compact-headline-flex">
                          <label
                            className="compact-checkbox-wrap"
                            title={`Seleccionar ${v.lemma}`}
                          >
                            <input
                              type="checkbox"
                              className="card-checkbox"
                              aria-label={`Seleccionar ${v.lemma}`}
                              checked={isSelected}
                              onChange={(e) =>
                                setSelected(
                                  e.target.checked
                                    ? [...selected, v.id]
                                    : selected.filter((id) => id !== v.id),
                                )
                              }
                            />
                          </label>
                          <span className="compact-avatar-box" aria-hidden="true">
                            {emoji}
                          </span>
                          <Link to={`/verbs/${v.id}`} className="compact-lemma-link">
                            {v.lemma}
                          </Link>
                          <span className="compact-meaning-label">
                            {v.meanings.slice(0, 2).join(' / ')}
                          </span>
                          <span className="compact-badge compact-level-badge">
                            {cefrLevel}
                          </span>
                          {pattern && (
                            <span className="compact-badge compact-pattern-badge">
                              {pattern}
                            </span>
                          )}
                        </div>
                        {/* Secondary phonetic IPA sequence with discrete audio trigger */}
                        <div className="compact-phonetics-row">
                          {baseIpa && (
                            <span className="compact-ipa-code">{formatIpa(baseIpa)}</span>
                          )}
                          {pastIpa && (
                            <>
                              <span className="compact-dot-sep">•</span>
                              <span className="compact-ipa-code">{formatIpa(pastIpa)}</span>
                            </>
                          )}
                          {partIpa && (
                            <>
                              <span className="compact-dot-sep">•</span>
                              <span className="compact-ipa-code">{formatIpa(partIpa)}</span>
                            </>
                          )}
                          <button
                            type="button"
                            className="compact-audio-btn"
                            title="Escuchar pronunciación"
                            onClick={() => void audio.play(v)}
                            aria-label={`Escuchar ${v.lemma}`}
                          >
                            <span
                              className="material-symbols-outlined"
                              style={{ fontSize: '14px' }}
                            >
                              volume_up
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Right: Conjugation capsule + Edit controls + Checkbox + Chevron button */}
                    <div className="compact-right-group">
                      <div className="compact-conjugation-capsule">
                        <div className="compact-form-item">
                          <span className="compact-form-tag">P:</span>
                          <span className="compact-form-val past">
                            {pastValues[0] || '—'}
                          </span>
                        </div>
                        <span className="compact-dot-sep">•</span>
                        <div className="compact-form-item">
                          <span className="compact-form-tag">PP:</span>
                          <span className="compact-form-val participle">
                            {partValues[0] || '—'}
                          </span>
                        </div>
                      </div>

                      <div className="compact-actions-cluster">
                        {editing && (
                          <>
                            <Link
                              to={`/editor/verbs/${v.id}`}
                              className="compact-tool-btn"
                              aria-label={`Editar ${v.lemma}`}
                              title="Editar verbo"
                            >
                              <span
                                className="material-symbols-outlined"
                                style={{ fontSize: '15px' }}
                              >
                                edit
                              </span>
                            </Link>
                            {showArchived ? (
                              <button
                                type="button"
                                className="compact-tool-btn"
                                aria-label={`Restaurar ${v.lemma}`}
                                title="Restaurar verbo"
                                disabled={restoring === v.id}
                                onClick={async () => {
                                  setRestoring(v.id);
                                  setActionError('');
                                  try {
                                    await restoreVerb(repos, v.id);
                                    await refresh();
                                    editToggle.current?.focus();
                                  } catch {
                                    setActionError(
                                      'No se pudo restaurar el verbo. Inténtalo de nuevo.',
                                    );
                                  } finally {
                                    setRestoring(null);
                                  }
                                }}
                              >
                                <span
                                  className="material-symbols-outlined"
                                  style={{ fontSize: '15px' }}
                                >
                                  restore
                                </span>
                              </button>
                            ) : (
                              <button
                                type="button"
                                className="compact-tool-btn danger"
                                aria-label={`Quitar ${v.lemma}`}
                                title="Archivar verbo"
                                onClick={() => setArchiving(v)}
                              >
                                <span
                                  className="material-symbols-outlined"
                                  style={{ fontSize: '15px' }}
                                >
                                  delete
                                </span>
                              </button>
                            )}
                          </>
                        )}

                        <Link
                          to={`/verbs/${v.id}`}
                          className="compact-nav-arrow-btn"
                          aria-label={`Ver ficha de ${v.lemma}`}
                          title="Ver detalles"
                        >
                          <span
                            className="material-symbols-outlined"
                            style={{ fontSize: '18px' }}
                          >
                            chevron_right
                          </span>
                        </Link>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {!result.total && (
            <div className="empty" style={{ marginTop: '24px' }}>
              <h2>No hay coincidencias</h2>
              <p>Prueba otra búsqueda o elimina algún filtro.</p>
              <button
                type="button"
                onClick={() => {
                  clearFilters();
                  setQ({ ...q, text: '', filter: {} });
                }}
              >
                Limpiar búsqueda
              </button>
            </div>
          )}

          <div className="row result-bottom">
            <p>Las recomendaciones de curso son orientativas y editables.</p>
            <button
              type="button"
              disabled={!selected.length}
              onClick={() => setNewList(true)}
              style={{
                background: selected.length ? '#4f46e5' : undefined,
                color: selected.length ? 'white' : undefined,
              }}
            >
              <Icon name="plus" />
              Guardar selección ({selected.length})
            </button>
          </div>
        </section>

        {/* Desktop Sidebar Column: Mis Listas & Consejos */}
        <aside className="catalog-aside">
          <div className="panel" style={{ borderRadius: '18px' }}>
            <div className="section-title">
              <Icon name="book" />
              <h2>Mis listas</h2>
            </div>
            <button
              type="button"
              className={!q.filter.listIds?.length ? 'list-item active' : 'list-item'}
              onClick={() => filter('listIds', '')}
            >
              Todos los verbos <span>{verbs.filter((v) => !v.archivedAt).length}</span>
            </button>
            {lists.map((l) => (
              <button
                key={l.id}
                type="button"
                className="list-item"
                onClick={() => filter('listIds', l.id)}
              >
                {l.name}
                <span>{l.verbIds.length}</span>
              </button>
            ))}
            {!lists.length && (
              <p className="muted small">
                Selecciona verbos y guárdalos juntos para tu próximo examen o práctica.
              </p>
            )}
            <button
              type="button"
              className="text-button"
              onClick={() => setNewList(true)}
              style={{ color: '#4f46e5', fontWeight: 600 }}
            >
              <Icon name="plus" size={18} />
              Crear una lista
            </button>
          </div>

          <div className="tip-card" style={{ borderRadius: '18px' }}>
            <span className="tip-icon">✦</span>
            <h3>Busca más allá del infinitivo</h3>
            <p>
              Puedes escribir formas en pasado, participio o incluso significados en español en la
              barra de búsqueda para encontrar cualquier verbo al instante.
            </p>
          </div>
        </aside>
      </div>

      {/* New List Modal Dialog */}
      {newList && (
        <Dialog title="Crear una lista personalizada" onClose={() => setNewList(false)}>
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              try {
                await saveList(repos, profile.id, {
                  name,
                  verbIds: selected,
                });
                await refresh();
                setNewList(false);
                setName('');
                setError('');
              } catch (e) {
                setError(String(e));
              }
            }}
          >
            <label>
              Nombre de la lista
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ej.: Examen de Navidad, Verbos difíciles..."
                autoFocus
              />
            </label>
            <p className="small muted">
              Se incluirán {selected.length} verbo{selected.length === 1 ? '' : 's'} seleccionados.
            </p>
            {error && <p role="alert">{error}</p>}
            <div className="actions">
              <button
                type="button"
                className="secondary"
                onClick={() => setNewList(false)}
              >
                Cancelar
              </button>
              <button disabled={!name.trim()}>Guardar lista</button>
            </div>
          </form>
        </Dialog>
      )}
    </div>
  );
}
