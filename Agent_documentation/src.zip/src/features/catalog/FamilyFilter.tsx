import { useEffect, useRef } from 'react';
import type { Verb } from '../../shared/domain/types';
import { familyLabel, getFamilyOptions, type RelationScope } from './family-filter';

export interface FamilyFilterProps {
  verbs: Verb[];
  relation: RelationScope;
  selected: string[] | null;
  onRelation: (relation: RelationScope) => void;
  onSelection: (selected: string[] | null) => void;
}

const relationButtons: { id: RelationScope; label: string; badge?: string; chipStyle: string }[] = [
  { id: '', label: 'Todas las relaciones', chipStyle: 'active' },
  { id: 'all_same', label: 'Tres iguales', badge: 'A-A-A', chipStyle: 'stitch-chip-teal-active' },
  {
    id: 'past_participle_same',
    label: 'Pasado y participio iguales',
    badge: 'A-B-B',
    chipStyle: 'stitch-chip-indigo-active',
  },
  {
    id: 'all_different',
    label: 'Tres diferentes',
    badge: 'A-B-C',
    chipStyle: 'stitch-chip-purple-active',
  },
  { id: 'special', label: 'Especiales', badge: 'Irregulares', chipStyle: 'stitch-chip-amber-active' },
];

export function FamilyFilter({
  verbs,
  relation,
  selected,
  onRelation,
  onSelection,
}: FamilyFilterProps) {
  const options = getFamilyOptions(verbs, relation);
  const ids = options.map((option) => option.id);
  const chosen = selected === null ? ids : ids.filter((id) => selected.includes(id));
  const all = chosen.length === ids.length && ids.length > 0;
  const partial = chosen.length > 0 && !all;
  const checkbox = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (checkbox.current) checkbox.current.indeterminate = partial;
  }, [partial]);

  return (
    <div className="stitch-family-filter-container">
      {/* 1. Header with Icon and Label */}
      <div className="filter-section-header">
        <span className="material-symbols-outlined" style={{ fontSize: '16px', color: '#4f46e5' }}>
          account_tree
        </span>
        <span>Relación de formas y familias</span>
      </div>

      {/* 2. Relation of Forms Chip Buttons */}
      <div className="filter-chips-wrap" role="group" aria-label="Relación de formas">
        {relationButtons.map((opt) => {
          const isSelected = relation === opt.id;
          return (
            <button
              type="button"
              key={opt.id}
              className={`stitch-chip-btn ${isSelected ? opt.chipStyle : ''}`}
              onClick={() => {
                onRelation(opt.id);
                onSelection(null);
              }}
            >
              <span>{opt.label}</span>
              {opt.badge && <span className="stitch-chip-badge-tag">{opt.badge}</span>}
            </button>
          );
        })}
      </div>

      {/* 3. Subtitle / Helper description */}
      <p className="filter-help-text">
        La relación selecciona sus familias. Desmarca las que quieras excluir. Un verbo puede
        pertenecer a varias familias.
      </p>

      {/* 4. Master Control Bar */}
      <div className="family-master-bar">
        <label className="family-master-label">
          <input
            ref={checkbox}
            type="checkbox"
            className="stitch-checkbox-input"
            checked={all}
            disabled={!ids.length}
            onChange={(event) => onSelection(event.target.checked ? null : [])}
            aria-label="Seleccionar o deseleccionar todas las familias"
          />
          <span className="family-master-title">Todas las familias</span>
        </label>
        <div className="family-master-actions">
          <span className="family-count-badge">
            {chosen.length} de {ids.length} familias seleccionadas
          </span>
          {ids.length > 0 && (
            <button
              type="button"
              className="family-toggle-all-btn"
              onClick={() => onSelection(all ? [] : null)}
            >
              {all ? 'Deseleccionar todas' : 'Seleccionar todas'}
            </button>
          )}
        </div>
      </div>

      {/* 5. Granular Families Grid */}
      <div className="family-cards-grid" role="group" aria-label="Familias de verbos detalladas">
        {options.map((option) => {
          const isChecked = chosen.includes(option.id);
          return (
            <label
              key={option.id}
              className={`stitch-family-card ${isChecked ? 'selected' : 'unselected'}`}
            >
              <input
                type="checkbox"
                className="stitch-checkbox-input"
                aria-label={familyLabel(option.id)}
                checked={isChecked}
                onChange={(event) => {
                  const next = event.target.checked
                    ? [...chosen, option.id]
                    : chosen.filter((id) => id !== option.id);
                  onSelection(next.length === ids.length ? null : next);
                }}
              />
              <span className="family-card-title">{familyLabel(option.id)}</span>
              <span className="family-card-count">
                {option.count} {option.count === 1 ? 'verbo' : 'verbos'}
              </span>
            </label>
          );
        })}
        {!options.length && (
          <div className="stitch-empty-families">
            No hay familias en esta relación.
          </div>
        )}
      </div>
    </div>
  );
}
