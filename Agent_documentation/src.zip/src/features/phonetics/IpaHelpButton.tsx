import { useState } from 'react';
import { Dialog } from '../../shared/ui/Dialog';

const symbols = [
  { symbol: 'iː', example: 'be, see, keep', desc: 'Vocal "i" larga y tensa' },
  { symbol: 'ɪ', example: 'sit, give, hit', desc: 'Vocal "i" corta y relajada' },
  { symbol: 'e', example: 'bed, get, read (past)', desc: 'Vocal "e" corta y abierta' },
  { symbol: 'æ', example: 'cat, swam, began', desc: 'Sonido entre "a" y "e"' },
  { symbol: 'ʌ', example: 'cut, run, won', desc: 'Vocal "a" corta y central' },
  { symbol: 'ɑː', example: 'far, heart, father', desc: 'Vocal "a" larga y profunda' },
  { symbol: 'ɔː', example: 'saw, thought, caught', desc: 'Vocal "o" larga y abierta' },
  { symbol: 'ʊ', example: 'put, took, stood', desc: 'Vocal "u" corta y relajada' },
  { symbol: 'uː', example: 'too, blew, grew', desc: 'Vocal "u" larga' },
  { symbol: 'ɜː', example: 'heard, hurt, burn', desc: 'Vocal central alargada' },
  { symbol: 'ə', example: 'ago, teacher, arise', desc: 'Schwa (vocal neutra átona)' },
  { symbol: 'eɪ', example: 'say, made, break', desc: 'Diptongo "ei"' },
  { symbol: 'aɪ', example: 'drive, write, fly', desc: 'Diptongo "ai"' },
  { symbol: 'ɔɪ', example: 'boy, join', desc: 'Diptongo "oi"' },
  { symbol: 'əʊ / oʊ', example: 'go, chose, spoke', desc: 'Diptongo "ou"' },
  { symbol: 'aʊ', example: 'found, bound', desc: 'Diptongo "au"' },
  { symbol: 'ɪə', example: 'hear, tear (lágrima)', desc: 'Diptongo "ie"' },
  { symbol: 'eə', example: 'bear, wear, tear (rasgar)', desc: 'Diptongo "ee"' },
  { symbol: 'θ', example: 'think, thought', desc: 'Sonido "z" suave española' },
  { symbol: 'ð', example: 'this, other', desc: 'Sonido "d" interdental' },
  { symbol: 'ŋ', example: 'sing, sang, sung', desc: 'N velar (al final de -ing)' },
  { symbol: 'ʃ', example: 'shoe, shot, shine', desc: 'Sonido "sh" suave' },
  { symbol: 'tʃ', example: 'choose, chose', desc: 'Sonido "ch"' },
  { symbol: 'dʒ', example: 'judge, bridge', desc: 'Sonido "y/dj" sonora' },
];

export function IpaHelpButton() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        type="button"
        className="secondary ipa-help-trigger"
        onClick={() => setOpen(true)}
        aria-label="Abrir guía de pronunciación fonética e IPA"
      >
        Guía fonética (IPA)
      </button>

      {open && (
        <Dialog title="Guía fonética y símbolos IPA" onClose={() => setOpen(false)}>
          <div className="ipa-help-content">
            <p>
              El alfabeto fonético internacional (IPA) permite reproducir fielmente la pronunciación británica (UK) y estadounidense (US) de cada forma verbal.
            </p>

            <dl className="ipa-reading-key" style={{ marginBottom: '16px' }}>
              <dt>ˈ (acento)</dt>
              <dd>Indica que la sílaba inmediatamente posterior lleva el acento principal.</dd>
              <dt>ː (duración)</dt>
              <dd>Indica que el sonido vocálico anterior es largo y sostenido.</dd>
              <dt>/ / (barras)</dt>
              <dd>Delimitan la transcripción fonémica oficial del término.</dd>
            </dl>

            <h3 style={{ fontSize: '15px', marginBottom: '10px' }}>Símbolos más frecuentes en los verbos irregulares</h3>
            <div className="ipa-symbol-grid">
              {symbols.map((item) => (
                <div key={item.symbol} className="ipa-symbol">
                  <strong>/{item.symbol}/</strong>
                  <span>{item.example}</span>
                  <small style={{ color: 'var(--muted, #64748b)', fontSize: '11px' }}>{item.desc}</small>
                </div>
              ))}
            </div>
          </div>
        </Dialog>
      )}
    </>
  );
}
