---
name: Kinetic Grammar
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#464555'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#00687a'
  on-secondary: '#ffffff'
  secondary-container: '#57dffe'
  on-secondary-container: '#006172'
  tertiary: '#571ac0'
  on-tertiary: '#ffffff'
  tertiary-container: '#6f3dd9'
  on-tertiary-container: '#e3d5ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#e9ddff'
  tertiary-fixed-dim: '#d0bcff'
  on-tertiary-fixed: '#23005c'
  on-tertiary-fixed-variant: '#5516be'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '800'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.06em
  label-badge:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.01em
  verb-root:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.02em
  verb-conjugation:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 22px
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

This design system crafts an energetic, high-focus educational interface tailored for digital-native teens aged 11 to 16. It balances the pristine structural rigor of an iOS/iPadOS application with vibrant, electric micro-interactions that make rote memorization of irregular verbs feel dynamic and game-adjacent without descending into juvenile gamification.

### Visual Style
- **iOS-Adjacent Modernity:** Employs precise typography, translucent frosted glass headers, squircle containers, and micro-fine hairline borders.
- **Electric Youth Vitality:** Leverages punchy indigo and hyper-saturated accent pairings (cyan, violet, mint) to provide high-contrast grammatical signifiers, CEFR badges, and streak mechanics.
- **Tactile Feedback:** Incorporates crisp active states, soft dimensional surface elevations, and refined spring-like transitions designed to make audio pronunciation triggers and flashcard flips satisfyingly tactile.

## Colors

The palette establishes an authoritative yet vibrant learning atmosphere. The primary electric indigo (#4F46E5) serves as the anchor for key interactive actions, active states, and dominant branding. Secondary electric cyan (#06B6D4) and tertiary vibrant violet (#8B5CF6) highlight auxiliary states, verb pattern classifications (e.g., *sing-sang-sung* vs. *cut-cut-cut*), and interactive progress rings. A crisp functional mint (#10B981) denotes correct mastery, streak states, and successful conjugations.

### Light Mode Foundations
- **Background Canvas:** `#F8FAFC`
- **Surface Elevation 1 (Card/Squircle):** `#FFFFFF`
- **Surface Translucent (Frosted):** `rgba(255, 255, 255, 0.78)`
- **Hairline Border:** `rgba(15, 23, 42, 0.08)`
- **Text Primary:** `#0F172A`
- **Text Muted:** `#64748B`

### Dark Mode Adaptation
- **Background Canvas:** `#090D16`
- **Surface Elevation 1:** `#131B2E`
- **Surface Translucent (Frosted):** `rgba(19, 27, 46, 0.75)`
- **Hairline Border:** `rgba(255, 255, 255, 0.12)`
- **Text Primary:** `#F8FAFC`
- **Text Muted:** `#94A3B8`

## Typography

Typography establishes textbook legibility through an Apple-inspired editorial lens. Headlines use **Plus Jakarta Sans** for soft, geometric confidence, giving verb titles and headings a welcoming, punchy presentation. Body copy and grammatical explanations rely on **Inter** for neutral, high-density legibility.

- **Conjugation Tiers:** Base/Infinitive forms utilize `verb-root`, while Past Simple and Past Participle elements employ `verb-conjugation` with medium font weight to maintain clean tabular comparison.
- **Grammar Tags:** CEFR levels (A1–C2) and irregular pattern classes map to `label-caps` (uppercase) or `label-badge` (sentence case) to guarantee rapid scanning without clashing with vocabulary text.

## Layout & Spacing

The layout operates on an 8-point base grid system enclosed in a fluid layout that conforms to maximum safe boundaries.

### Breakpoints & Adaptive Flow
- **Mobile (< 640px):** Single-column stacked stream. Screen margins standardise at `1rem`. Conjugation triplets (Base, Past Simple, Past Participle) stack vertically or utilize horizontal swipe carousels.
- **Tablet (640px – 1024px):** 6-column grid with `1.5rem` margins and `1rem` gutters. Verb items display in side-by-side modular tiles.
- **Desktop (> 1024px):** 12-column responsive layout capped at a maximum width of `1200px`. Sticky filter panels on the left (3 columns) paired with a high-density verb catalog (9 columns).

## Elevation & Depth

Visual hierarchy uses frosted glass blurs, hairline structural borders, and diffuse ambient drops:

- **Level 0 (Flat Canvas):** Raw neutral background (`#F8FAFC` light / `#090D16` dark).
- **Level 1 (Card & Squircle Content):** Pure white or dark slate containers supported by a micro-border (`1px solid rgba(15, 23, 42, 0.08)`) and an ambient glow: `0px 4px 16px -2px rgba(15, 23, 42, 0.04)`.
- **Level 2 (Interactive Floating / Frosted Navigation):** Backdrop filter `blur(16px)` with a translucent surface. Shadows gain soft, tinted grounding: `0px 10px 25px -4px rgba(79, 70, 229, 0.08)`.
- **Level 3 (Modals & Practice Sheets):** Deep soft elevation: `0px 20px 40px -8px rgba(15, 23, 42, 0.16)` enclosed in an accented hairline border.

## Shapes

The geometric identity relies on Apple-style squircles at Level 2 roundedness:

- **Base Radius (`rounded-md`):** `0.5rem` (8px) applied to inputs, auxiliary buttons, audio controls, and table rows.
- **Container Radius (`rounded-lg`):** `1rem` (16px) applied to verb cards, floating action drawers, and modal sheets.
- **Hero / Card Radius (`rounded-xl`):** `1.5rem` (24px) reserved for primary practice hero boards and quiz surfaces.
- **Pill Badges:** Fully rounded (`9999px`) used for CEFR tags, verb pattern chips, and filter toggles.

## Components

### Buttons & Interactive Controls
- **Primary Action:** Squircles styled with `#4F46E5`, white text, and a subtle inset highlight border (`inset 0 1px 0 rgba(255, 255, 255, 0.2)`). Active state applies a scale transformation of `0.97`.
- **Audio Pronunciation Button:** Compact `40x40px` circular squircle with a frosted backdrop, electric indigo icon, and dynamic audio wave indicator that ripples when pressed.

### CEFR & Grammatical Badges
- **Pill Shape:** Fully rounded badges with soft tinted background (`12% opacity`) and high-contrast solid text:
  - *A1/A2:* Soft Mint (`#10B981`)
  - *B1/B2:* Electric Cyan (`#06B6D4`)
  - *C1/C2:* Vibrant Violet (`#8B5CF6`)
  - *Pattern Tags (e.g., A-B-B, A-B-C):* Indigo tint with `0.5px` border.

### Search Bar & Filter Chips
- **Search Bar:** Centered pill squircle container with frosted background, subtle hairline outline, and an embedded clear trigger.
- **Filter Chips:** Horizontally scrollable pill buttons. Selected state swaps from translucent gray to solid Indigo fill with high-contrast text.

### Verb List Cards
- **Card Structure:** Rounded-lg surface showcasing the three core forms (Infinitive, Past Simple, Past Participle) in three distinct, balanced visual segments.
- **Interactive State:** Hover elevates card by 2px and highlights irregular vowel changes with a subtle tertiary color tint.

### Toggle Controls
- **iOS-Style Track:** Smooth rounded pill switch with a white floating circle thumb that glides across states, powered by a spring curve transition.